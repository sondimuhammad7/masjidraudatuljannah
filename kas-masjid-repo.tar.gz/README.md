# 🕌 Kas Masjid — Sistem Keuangan Masjid Raudatul Janah

Aplikasi web sederhana (single-file HTML) untuk mencatat transaksi kas masjid: pemasukan, pengeluaran, saldo, grafik, dan export laporan ke PDF.

## Fitur
- Input transaksi (tanggal, jenis, keterangan, nominal)
- Ringkasan otomatis: total pemasukan, pengeluaran, saldo
- Grafik keuangan (Chart.js)
- Export laporan ke PDF (jsPDF)
- Data tersimpan di `localStorage` browser (tanpa backend/server)

## Cara Pakai
1. Buka `index.html` langsung di browser, atau
2. Deploy gratis ke GitHub Pages / Netlify / Vercel

## Deploy ke GitHub Pages
1. Push repo ini ke GitHub
2. Buka **Settings > Pages**
3. Pilih branch `main` dan folder `/root`
4. Situs akan aktif di `https://<username>.github.io/<nama-repo>/`

## Catatan
Karena data disimpan di `localStorage`, data **hanya tersimpan di browser & perangkat yang sama**. Untuk penggunaan multi-user (misalnya diakses beberapa pengurus masjid dari device berbeda), aplikasi ini perlu backend/database (misalnya Google Sheets API, Firebase, atau server sendiri).

## Lisensi
Bebas digunakan untuk kebutuhan masjid/komunitas.
